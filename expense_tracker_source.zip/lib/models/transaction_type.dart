enum TransactionType {
  income,
  expense,
}
