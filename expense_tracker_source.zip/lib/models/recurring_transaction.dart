import 'expense_category.dart';
import 'income_category.dart';
import 'payment_method.dart';
import 'transaction_type.dart';

enum RecurrenceFrequency { daily, weekly, monthly, yearly }

class RecurringTransaction {
  final String id;
  final String name;
  final double amount;
  final TransactionType type;
  final ExpenseCategory? expenseCategory;
  final IncomeCategory? incomeCategory;
  final PaymentMethod paymentMethod;
  final DateTime startDate;
  final RecurrenceFrequency frequency;
  final bool isActive;

  const RecurringTransaction({
    required this.id,
    required this.name,
    required this.amount,
    required this.type,
    this.expenseCategory,
    this.incomeCategory,
    required this.paymentMethod,
    required this.startDate,
    required this.frequency,
    this.isActive = true,
  });
}
