import 'package:flutter/material.dart';

import '../models/expense_category.dart';
import '../models/transaction.dart';
import '../models/transaction_type.dart';
import '../utils/date_formatter.dart';
import '../utils/transaction_helpers.dart';

class TransactionTile extends StatelessWidget {
  final Transaction transaction;
  final VoidCallback onTap;

  const TransactionTile({
    super.key,
    required this.transaction,
    required this.onTap,
  });

  IconData getCategoryIcon() {
    switch (transaction.expenseCategory!) {
      case ExpenseCategory.food:
        return Icons.restaurant;

      case ExpenseCategory.transport:
        return Icons.directions_bus;

      case ExpenseCategory.shopping:
        return Icons.shopping_bag;

      case ExpenseCategory.bills:
        return Icons.receipt_long;

      case ExpenseCategory.entertainment:
        return Icons.movie;

      case ExpenseCategory.other:
        return Icons.attach_money;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isIncome = transaction.type == TransactionType.income;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),

      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),

        onTap: onTap,

        leading: CircleAvatar(
          child: Icon(isIncome ? Icons.savings : getCategoryIcon()),
        ),

        title: Text(
          transaction.name,

          style: const TextStyle(fontWeight: FontWeight.bold),
        ),

        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isIncome
                  ? 'Income • '
                        '${paymentMethodDisplayName(transaction.paymentMethod)}'
                  : '${categoryDisplayName(transaction.expenseCategory!)} • '
                        '${paymentMethodDisplayName(transaction.paymentMethod)}',
            ),
            Text(formatDate(transaction.date)),
          ],
        ),

        trailing: Text(
          '${isIncome ? '+' : '-'}'
          '₹${transaction.amount.toStringAsFixed(2)}',

          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isIncome ? Colors.green : Colors.red,
          ),
        ),
      ),
    );
  }
}
