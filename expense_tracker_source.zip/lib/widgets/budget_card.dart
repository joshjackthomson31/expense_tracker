import 'package:flutter/material.dart';

import '../models/budget.dart';
import '../utils/budget_calculator.dart';
import '../utils/transaction_helpers.dart';

class BudgetCard extends StatelessWidget {
  final Budget budget;
  final double amountSpent;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const BudgetCard({
    super.key,
    required this.budget,
    required this.amountSpent,
    required this.onEdit,
    required this.onDelete,
  });

  String _formatAmount(double amount) => '₹${amount.toStringAsFixed(2)}';

  String _monthName(int month) {
    const monthNames = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return month >= 1 && month <= 12 ? monthNames[month - 1] : 'Month $month';
  }

  @override
  Widget build(BuildContext context) {
    final limit = budget.monthlyLimit;
    final remaining = calculateRemainingBudget(
      budgetLimit: limit,
      amountSpent: amountSpent,
    );
    final percentage = calculateBudgetPercentage(
      budgetLimit: limit,
      amountSpent: amountSpent,
    );
    final status = getBudgetStatus(
      amountSpent: amountSpent,
      budgetLimit: limit,
    );
    final colorScheme = Theme.of(context).colorScheme;
    final statusColor = switch (status) {
      'Budget exceeded' => colorScheme.error,
      'Approaching budget limit' => Colors.orange.shade800,
      'Invalid budget limit' => colorScheme.error,
      _ => colorScheme.primary,
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${categoryDisplayName(budget.category)} budget',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  tooltip: 'Edit budget',
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_outlined),
                ),
                IconButton(
                  tooltip: 'Delete budget',
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            Text('${_monthName(budget.month)} ${budget.year}'),
            const SizedBox(height: 8),
            Text(
              'Spent ${_formatAmount(amountSpent)} of ${_formatAmount(limit)}',
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: limit > 0 ? (amountSpent / limit).clamp(0.0, 1.0) : 0,
              color: statusColor,
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${percentage.toStringAsFixed(0)}% used'),
                Text(
                  remaining >= 0
                      ? '${_formatAmount(remaining)} remaining'
                      : '${_formatAmount(-remaining)} over budget',
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              status,
              style: Theme.of(context).textTheme.labelLarge
                  ?.copyWith(color: statusColor),
            ),
          ],
        ),
      ),
    );
  }
}
