import '../models/recurring_transaction.dart';

DateTime calculateNextDueDate({
  required DateTime currentDueDate,
  required RecurrenceFrequency frequency,
  int? preferredDay,
}) {
  switch (frequency) {
    case RecurrenceFrequency.daily:
      return currentDueDate.add(const Duration(days: 1));
    case RecurrenceFrequency.weekly:
      return currentDueDate.add(const Duration(days: 7));
    case RecurrenceFrequency.monthly:
      final nextMonth = DateTime(
        currentDueDate.year,
        currentDueDate.month + 1,
        1,
      );
      final lastDayOfMonth = DateTime(
        nextMonth.year,
        nextMonth.month + 1,
        0,
      ).day;
      final desiredDay = preferredDay ?? currentDueDate.day;
      final safeDay = desiredDay.clamp(1, lastDayOfMonth).toInt();

      return DateTime(nextMonth.year, nextMonth.month, safeDay);
    case RecurrenceFrequency.yearly:
      final nextYear = currentDueDate.year + 1;
      final desiredDay = preferredDay ?? currentDueDate.day;
      final lastDayOfMonth = DateTime(
        nextYear,
        currentDueDate.month + 1,
        0,
      ).day;
      final safeDay = desiredDay.clamp(1, lastDayOfMonth).toInt();

      return DateTime(nextYear, currentDueDate.month, safeDay);
  }
}

String createOccurrenceKey({
  required String recurringId,
  required DateTime dueDate,
}) {
  final dateKey =
      '${dueDate.year}-'
      '${dueDate.month.toString().padLeft(2, '0')}-'
      '${dueDate.day.toString().padLeft(2, '0')}';

  return '${recurringId}_$dateKey';
}
