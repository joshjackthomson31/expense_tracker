import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/analytics_period.dart';
import '../models/expense_category.dart';
import '../models/payment_method.dart';
import '../models/transaction.dart';
import '../providers/transaction_provider.dart';
import '../utils/analytics_calculator.dart';
import '../utils/date_filter.dart';
import '../utils/transaction_helpers.dart';
import '../utils/spending_chart_calculator.dart';
import '../utils/transaction_calculator.dart';
import '../widgets/analytics_summary_card.dart';
import '../widgets/balance_card.dart';
import '../widgets/monthly_spending_chart.dart';
import '../widgets/summary_card.dart';
import '../widgets/weekly_spending_chart.dart';

class AnalyticsScreen extends ConsumerStatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  ConsumerState<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends ConsumerState<AnalyticsScreen> {
  AnalyticsPeriod selectedPeriod = AnalyticsPeriod.thisMonth;
  int selectedMonth = DateTime.now().month;
  int selectedYear = DateTime.now().year;

  static const monthLabels = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  static const categoryColors = [
    Colors.blue,
    Colors.orange,
    Colors.green,
    Colors.purple,
    Colors.red,
    Colors.teal,
  ];

  Color colorForCategory(ExpenseCategory category) {
    return categoryColors[category.index % categoryColors.length];
  }

  List<Transaction> filterByPeriod(List<Transaction> transactions) {
    final now = DateTime.now();

    switch (selectedPeriod) {
      case AnalyticsPeriod.today:
        return filterTransactionsByDay(transactions, now);

      case AnalyticsPeriod.thisWeek:
        return filterTransactionsByWeek(transactions, now);

      case AnalyticsPeriod.thisMonth:
        return filterTransactionsByYearMonth(
          transactions,
          selectedYear,
          selectedMonth,
        );
    }
  }

  List<int> availableYears(List<Transaction> transactions) {
    final years = {
      DateTime.now().year,
      ...transactions.map((transaction) => transaction.date.year),
    }.toList()..sort();

    return years;
  }

  @override
  Widget build(BuildContext context) {
    final transactionsAsync = ref.watch(transactionProvider);

    return transactionsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('Error: $error')),
      data: (transactions) {
        return _buildAnalytics(context, transactions);
      },
    );
  }

  Widget _buildAnalytics(BuildContext context, List<Transaction> transactions) {
    final filteredTransactions = filterByPeriod(transactions);

    final periodSelector = Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),

      child: SegmentedButton<AnalyticsPeriod>(
        segments: const [
          ButtonSegment(value: AnalyticsPeriod.today, label: Text('Today')),
          ButtonSegment(value: AnalyticsPeriod.thisWeek, label: Text('Week')),
          ButtonSegment(value: AnalyticsPeriod.thisMonth, label: Text('Month')),
        ],

        selected: {selectedPeriod},

        onSelectionChanged: (selection) {
          setState(() {
            selectedPeriod = selection.first;
          });
        },
      ),
    );

    final yearOptions = {...availableYears(transactions), selectedYear}.toList()
      ..sort();

    final monthSelector = selectedPeriod == AnalyticsPeriod.thisMonth
        ? Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButton<int>(
                    value: selectedMonth,
                    isExpanded: true,

                    items: List.generate(12, (index) {
                      final month = index + 1;

                      return DropdownMenuItem(
                        value: month,
                        child: Text(monthLabels[index]),
                      );
                    }),

                    onChanged: (month) {
                      if (month == null) return;

                      setState(() {
                        selectedMonth = month;
                      });
                    },
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: DropdownButton<int>(
                    value: selectedYear,
                    isExpanded: true,

                    items: yearOptions.map((year) {
                      return DropdownMenuItem(
                        value: year,
                        child: Text('$year'),
                      );
                    }).toList(),

                    onChanged: (year) {
                      if (year == null) return;

                      setState(() {
                        selectedYear = year;
                      });
                    },
                  ),
                ),
              ],
            ),
          )
        : const SizedBox.shrink();

    if (filteredTransactions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Analytics')),

        body: Padding(
          padding: const EdgeInsets.all(16),

          child: Column(
            children: [
              periodSelector,
              monthSelector,

              const Expanded(
                child: Center(
                  child: Text(
                    'No transactions for this period',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final totalExpenses = calculateTotalExpense(filteredTransactions);
    final totalIncome = calculateTotalIncome(filteredTransactions);
    final balance = calculateBalance(filteredTransactions);
    final savingsRate = calculateSavingsRate(filteredTransactions);

    final selectedDate = DateTime(selectedYear, selectedMonth);
    final currentMonthExpenses = getMonthlyExpenses(
      transactions,
      selectedYear,
      selectedMonth,
    );
    final previousMonthDate = DateTime(selectedYear, selectedMonth - 1);
    final previousMonthExpenses = getMonthlyExpenses(
      transactions,
      previousMonthDate.year,
      previousMonthDate.month,
    );
    final expenseChange = calculatePercentageChange(
      currentMonthExpenses,
      previousMonthExpenses,
    );

    final expensesByCategory = calculateExpensesByCategory(
      filteredTransactions,
    );

    final categoryTotals = ExpenseCategory.values
        .where((category) => (expensesByCategory[category] ?? 0) > 0)
        .map((category) => MapEntry(category, expensesByCategory[category]!))
        .toList();

    final sections = categoryTotals.map((entry) {
      final percentage = (entry.value / totalExpenses) * 100;

      return PieChartSectionData(
        value: entry.value,
        title: '${percentage.toStringAsFixed(0)}%',
        color: colorForCategory(entry.key),
        radius: 100,
      );
    }).toList();

    final paymentMethodTotals = PaymentMethod.values
        .map((method) {
          return MapEntry(
            method,
            calculatePaymentMethodTotal(filteredTransactions, method),
          );
        })
        .where((entry) => entry.value > 0)
        .toList();

    final today = DateTime.now();
    final weekStart = startOfWeek(today);
    final dailySpending = calculateWeeklySpending(transactions, today);

    final monthlySpending = calculateMonthlySpending(
      transactions,
      selectedDate,
      6,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Analytics')),

      body: ListView(
        padding: const EdgeInsets.all(16),

        children: [
          periodSelector,
          monthSelector,

          const SizedBox(height: 8),

          BalanceCard(balance: balance),

          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: SummaryCard(
                  title: 'Income',
                  amount: totalIncome,
                  icon: Icons.arrow_downward,
                  iconColor: Colors.green,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: SummaryCard(
                  title: 'Expenses',
                  amount: totalExpenses,
                  icon: Icons.arrow_upward,
                  iconColor: Colors.red,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: AnalyticsSummaryCard(
                  title: 'Savings Rate',
                  value: '${savingsRate.toStringAsFixed(1)}%',
                  icon: Icons.savings,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: AnalyticsSummaryCard(
                  title: 'Expenses vs Last Month',
                  value: expenseChange == null
                      ? 'No previous data'
                      : '${expenseChange >= 0 ? '+' : ''}'
                            '${expenseChange.toStringAsFixed(1)}%',
                  icon: Icons.compare_arrows,
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          const Text(
            'Weekly Spending',

            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 16),

          WeeklySpendingChart(
            dailySpending: dailySpending,
            weekStart: weekStart,
          ),

          const SizedBox(height: 24),

          const Text(
            'Monthly Spending Trend',

            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 16),

          MonthlySpendingChart(monthlySpending: monthlySpending),

          const SizedBox(height: 24),

          const Text(
            'Expense Breakdown',

            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 16),

          if (categoryTotals.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 32),
              child: Center(child: Text('No spending data for this period.')),
            )
          else ...[
            SizedBox(
              height: 300,

              child: PieChart(PieChartData(sections: sections)),
            ),

            const SizedBox(height: 24),

            const Text(
              'By Category',

              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 8),

            for (final entry in categoryTotals)
              ListTile(
                leading: CircleAvatar(
                  radius: 8,
                  backgroundColor: colorForCategory(entry.key),
                ),

                title: Text(categoryDisplayName(entry.key)),

                subtitle: Text(
                  '${((entry.value / totalExpenses) * 100).toStringAsFixed(0)}'
                  '% of total spending',
                ),

                trailing: Text(
                  '₹${entry.value.toStringAsFixed(2)}',

                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
          ],

          const SizedBox(height: 24),

          const Text(
            'By Payment Method',

            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),

          const SizedBox(height: 8),

          for (final entry in paymentMethodTotals)
            ListTile(
              title: Text(paymentMethodDisplayName(entry.key)),

              subtitle: Text(
                '${((entry.value / totalExpenses) * 100).toStringAsFixed(0)}'
                '% of total spending',
              ),

              trailing: Text(
                '₹${entry.value.toStringAsFixed(2)}',

                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
        ],
      ),
    );
  }
}
