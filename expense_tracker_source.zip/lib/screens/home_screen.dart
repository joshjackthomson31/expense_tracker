import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/transaction.dart';
import '../providers/transaction_provider.dart';
import '../utils/transaction_calculator.dart';
import '../widgets/balance_card.dart';
import '../widgets/summary_card.dart';
import '../widgets/transaction_tile.dart';
import 'add_transaction_screen.dart';
import 'analytics_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> addTransaction(BuildContext context, WidgetRef ref) async {
    final transaction = await Navigator.push<Transaction>(
      context,
      MaterialPageRoute(builder: (context) => const AddTransactionScreen()),
    );

    if (transaction != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaction added successfully')),
      );
    }
  }

  Future<void> editTransaction(
    BuildContext context,
    WidgetRef ref,
    Transaction transaction,
  ) async {
    final updatedTransaction = await Navigator.push<Transaction>(
      context,
      MaterialPageRoute(
        builder: (context) => AddTransactionScreen(transaction: transaction),
      ),
    );

    if (updatedTransaction != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaction updated successfully')),
      );
    }
  }

  void openAnalytics(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AnalyticsScreen()),
    );
  }

  String greeting() {
    final hour = DateTime.now().hour;

    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';

    return 'Good evening';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final transactionsAsync = ref.watch(transactionProvider);

    return transactionsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('Error: $error')),
      data: (transactions) {
        final balance = calculateBalance(transactions);
        final totalIncome = calculateTotalIncome(transactions);
        final totalExpenses = calculateTotalExpense(transactions);

        final recentTransactions = ([
          ...transactions,
        ]..sort((a, b) => b.date.compareTo(a.date))).take(5).toList();

        return Scaffold(
          appBar: AppBar(title: const Text('Expense Tracker')),

          body: ListView(
            padding: const EdgeInsets.all(16),

            children: [
              Text(
                greeting(),

                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 4),

              const Text("Here's your spending summary"),

              const SizedBox(height: 20),

              BalanceCard(balance: balance),

              const SizedBox(height: 20),

              Row(
                children: [
                  Expanded(
                    child: SummaryCard(
                      title: 'Income',
                      amount: totalIncome,
                      icon: Icons.arrow_downward,
                      iconColor: Colors.green,
                    ),
                  ),

                  const SizedBox(width: 16),

                  Expanded(
                    child: SummaryCard(
                      title: 'Expenses',
                      amount: totalExpenses,
                      icon: Icons.arrow_upward,
                      iconColor: Colors.red,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => addTransaction(context, ref),
                      icon: const Icon(Icons.add),
                      label: const Text('Add Transaction'),
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => openAnalytics(context),
                      icon: const Icon(Icons.analytics),
                      label: const Text('Analytics'),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              const Text(
                'Recent Transactions',

                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 10),

              if (transactions.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),

                  child: Text(
                    'No transactions yet.\nAdd your first expense!',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                )
              else
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),

                  itemCount: recentTransactions.length,

                  itemBuilder: (context, index) {
                    final transaction = recentTransactions[index];

                    return Dismissible(
                      key: Key(transaction.id),

                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),

                        child: const Icon(Icons.delete, size: 30),
                      ),

                      onDismissed: (direction) {
                        ref
                            .read(transactionProvider.notifier)
                            .deleteTransaction(transaction.id);

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text('Transaction deleted'),

                            action: SnackBarAction(
                              label: 'UNDO',
                              onPressed: () {
                                ref
                                    .read(transactionProvider.notifier)
                                    .addTransaction(transaction);
                              },
                            ),
                          ),
                        );
                      },

                      child: TransactionTile(
                        transaction: transaction,
                        onTap: () => editTransaction(context, ref, transaction),
                      ),
                    );
                  },
                ),
            ],
          ),

          // =========================
          // Add Expense Button
          // =========================
          floatingActionButton: FloatingActionButton(
            onPressed: () => addTransaction(context, ref),

            child: const Icon(Icons.add),
          ),
        );
      },
    );
  }
}
